// Canvas layout and drawing. Reads state. Does not change the board.

import { W, H, COLS, ROWS, CELL, PAD, BX, BW, BH, COLORS } from './sim.js';
import { Ease, eachParticle } from './fx.js';

export const C = {
  bg: '#2a2030', top: '#1d1620', cell: '#2f2637', line: '#241c2a',
  muted: '#6c5c78', panel: '#1f1823', slot: '#272030', deco: '#3b3043',
  white: '#ffffff', danger: '#d24b2d'
};
const FONT = '"Avenir Next", "Exo 2", "Trebuchet MS", "Segoe UI", system-ui, sans-serif';

const PANEL_H = 270;

export const GO_RESTART = { x: 215, y: 850, w: 320, h: 100 };
export const PA_RESUME  = { x: 215, y: 640, w: 320, h: 100 };

const DECO = [
  [737, .14, 10], [148, .22, 9], [710, .25, 9], [277, .78, 8], [501, .77, 8],
  [745, .80, 9], [78, .95, 8], [24, .48, 8], [728, .59, 7], [18, .31, 6], [380, .99, 7]
];

export const layout = {
  VH: H,
  OY: 0,
  BY: 0,
  HY: 0,
  COMBO_Y: 0,
  PANEL: { x: 48, y: 0, w: 654, h: PANEL_H },
  PREV_Y: 0,
  RESTART_BTN: { x: 52, y: 0, w: 80, h: 80 },
  PAUSE_BTN: { x: 617, y: 0, w: 80, h: 80 }
};

let canvas, ctx, safeProbe;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function place(safeTop, safeBot) {
  const top = safeTop + 24;
  layout.HY = top + 40;
  layout.RESTART_BTN.y = layout.HY - 40;
  layout.PAUSE_BTN.y = layout.HY - 40;
  layout.PANEL.y = layout.VH - safeBot - 28 - PANEL_H;
  layout.PREV_Y = layout.PANEL.y + 77;
  const minBY = layout.HY + 150;
  const maxBY = layout.PANEL.y - 30 - BH;
  layout.BY = Math.round(Math.max(minBY, minBY + (maxBY - minBY) * 0.6));
  layout.COMBO_Y = Math.round((layout.HY + 45 + layout.BY) / 2);
}

export function bindCanvas(el) {
  canvas = el;
  ctx = canvas.getContext('2d');
  safeProbe = document.createElement('div');
  safeProbe.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;' +
    'padding-top:env(safe-area-inset-top);padding-bottom:env(safe-area-inset-bottom)';
  document.body.appendChild(safeProbe);
  resize();
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', () => setTimeout(resize, 100));
}

export function resize() {
  const vw = window.innerWidth, vh = window.innerHeight;
  layout.VH = vw < vh ? Math.max(H, W * vh / vw) : H;
  layout.OY = (layout.VH - H) / 2;
  const s = Math.min(vw / W, vh / layout.VH);
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  const cssW = Math.floor(W * s), cssH = Math.floor(layout.VH * s);
  canvas.style.width = cssW + 'px';
  canvas.style.height = cssH + 'px';
  document.body.style.background = vw < vh ? C.bg : '';
  canvas.width = Math.round(cssW * dpr);
  canvas.height = Math.round(cssH * dpr);
  ctx.setTransform(canvas.width / W, 0, 0, canvas.height / layout.VH, 0, 0);
  const cs = getComputedStyle(safeProbe);
  const k = layout.VH / Math.max(1, cssH);
  place((parseFloat(cs.paddingTop) || 0) * k, (parseFloat(cs.paddingBottom) || 0) * k);
}

export function toLogical(e) {
  const r = canvas.getBoundingClientRect();
  return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * layout.VH / r.height };
}

export const toOverlay = p => ({ x: p.x, y: p.y - layout.OY });

export const hit = (b, p) => p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h;

function rr(x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function text(str, x, y, size, color, align = 'center', weight = 800, base = 'middle') {
  ctx.font = `${weight} ${size}px ${FONT}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = base;
  ctx.fillText(str, x, y);
}

function drawRestart(cx, cy, color) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const r = 16;
  const end = -1.05;
  ctx.beginPath();
  ctx.arc(0, 1, r, 0.7, Math.PI * 2 + end);
  ctx.stroke();
  const px = Math.cos(end) * r;
  const py = Math.sin(end) * r + 1;
  const tx = Math.cos(end + Math.PI / 2);
  const ty = Math.sin(end + Math.PI / 2);
  const nx = Math.cos(end);
  const ny = Math.sin(end);
  ctx.beginPath();
  ctx.moveTo(px + tx * 13, py + ty * 13);
  ctx.lineTo(px - tx * 3 + nx * 9, py - ty * 3 + ny * 9);
  ctx.lineTo(px - tx * 3 - nx * 9, py - ty * 3 - ny * 9);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawPause(cx, cy, color) {
  ctx.fillStyle = color;
  rr(cx - 17, cy - 22, 12, 44, 5); ctx.fill();
  rr(cx + 5, cy - 22, 12, 44, 5); ctx.fill();
}

function drawBlock(b, v, lifted) {
  if (v.s <= 0) return;
  const x = BX + v.vx * CELL + PAD, y = layout.BY + v.vy * CELL + PAD;
  const w = b.len * CELL - 2 * PAD, h = CELL - 2 * PAD;
  ctx.save();
  ctx.globalAlpha = clamp(v.alpha, 0, 1);
  if (v.s !== 1) {
    ctx.translate(x + w / 2, y + h / 2);
    ctx.scale(v.s, v.s);
    ctx.translate(-(x + w / 2), -(y + h / 2));
  }
  if (v.sq && !v.clearing) {
    const sx = 1 + v.sq * 0.6 / b.len, sy = 1 - v.sq;
    ctx.translate(x + w / 2, y + h); ctx.scale(sx, sy); ctx.translate(-(x + w / 2), -(y + h));
  }
  if (lifted) {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    rr(x + 4, y + 8, w, h, 7); ctx.fill();
  }
  ctx.fillStyle = COLORS[b.color];
  rr(x, y, w, h, 7); ctx.fill();
  if (lifted) {
    ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 3;
    rr(x + 1.5, y + 1.5, w - 3, h - 3, 6); ctx.stroke();
  }
  if (v.flash > 0) {
    ctx.fillStyle = `rgba(255,255,255,${Math.min(0.85, 0.85 * v.flash)})`;
    rr(x, y, w, h, 7); ctx.fill();
  }
  if (v.danger > 0) {
    ctx.fillStyle = `rgba(40,0,10,${0.45 * v.danger})`;
    rr(x, y, w, h, 7); ctx.fill();
    ctx.strokeStyle = `rgba(255,90,70,${v.danger})`; ctx.lineWidth = 4;
    rr(x + 2, y + 2, w - 4, h - 4, 6); ctx.stroke();
  }
  ctx.restore();
}

function drawButton(b, label, color) {
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  rr(b.x, b.y + 8, b.w, b.h, 20); ctx.fill();
  ctx.fillStyle = color;
  rr(b.x, b.y, b.w, b.h, 20); ctx.fill();
  text(label, b.x + b.w / 2, b.y + b.h / 2 + 2, 42, C.white);
}

function drawCard(x, y, w, h) {
  ctx.fillStyle = C.bg;
  rr(x, y, w, h, 26); ctx.fill();
  ctx.strokeStyle = '#43374c'; ctx.lineWidth = 4;
  rr(x, y, w, h, 26); ctx.stroke();
}

export function draw(now, state, viewOf, present) {
  const { VH, OY, BY, HY, COMBO_Y, PANEL, PREV_Y } = layout;
  ctx.fillStyle = C.bg;
  ctx.fillRect(0, 0, W, VH);
  ctx.save();
  if (present.shake) ctx.translate(present.shake, 0);

  ctx.fillStyle = C.deco;
  DECO.forEach(([x, fy, s], i) => {
    const oy = Math.sin(now / 1400 + i * 1.7) * 3;
    ctx.fillRect(x - s / 2, fy * VH - s / 2 + oy, s, s);
  });

  if (state.phase !== 'pause') drawRestart(92, HY, C.muted);
  drawPause(657, HY, C.muted);
  text(String(Math.round(present.displayScore)), W / 2, HY + 3, 76, C.muted);

  if (present.comboFx) {
    const age = now - present.comboFx.t0;
    if (age < 1740) {
      const sc = age < 260 ? Math.max(0, Ease.outBack(age / 260))
        : age > 1400 ? Math.max(0, 1 - Ease.inBack((age - 1400) / 340)) : 1;
      ctx.save();
      const cy = COMBO_Y;
      // Text and glow share the same scale-only entrance and exit.
      ctx.translate(W / 2, cy); ctx.scale(sc, sc); ctx.translate(-W / 2, -cy);
      const g = ctx.createRadialGradient(W / 2, cy + 6, 0, W / 2, cy + 6, 68);
      g.addColorStop(0, 'rgba(155,70,215,0.4)');
      g.addColorStop(1, 'rgba(155,70,215,0)');
      ctx.fillStyle = g;
      ctx.fillRect(W / 2 - 68, cy - 62, 136, 136);
      const ptsStr = String(present.comboFx.pts);
      const multStr = present.comboFx.mult > 1 ? 'x' + present.comboFx.mult : '';
      ctx.font = `800 68px ${FONT}`; const w1 = ctx.measureText(ptsStr).width;
      ctx.font = `800 47px ${FONT}`; const w2 = multStr ? ctx.measureText(multStr).width : 0;
      const gap = multStr ? 14 : 0;
      const x0 = W / 2 - (w1 + gap + w2) / 2;
      text(ptsStr, x0, cy + 25, 68, C.white, 'left', 800, 'alphabetic');
      if (multStr) text(multStr, x0 + w1 + gap, cy + 25, 47, C.white, 'left', 800, 'alphabetic');
      ctx.restore();
    }
  } else if (!state.hasMoved && state.phase !== 'over') {
    const a = 0.55 + 0.25 * Math.sin(now / 400);
    ctx.globalAlpha = a;
    text('Slide a block to fill a row', W / 2, COMBO_Y + 6, 30, '#9c89a8', 'center', 700);
    ctx.globalAlpha = 1;
  }

  ctx.fillStyle = C.line;
  ctx.fillRect(BX, BY, BW, BH);
  ctx.fillStyle = C.cell;
  for (let r = 0; r < ROWS; r++)
    for (let c = 0; c < COLS; c++)
      ctx.fillRect(BX + c * CELL + 1, BY + r * CELL + 1, CELL - 2, CELL - 2);

  if (state.phase !== 'over' && state.blocks.some(b => b.row === 0 && viewOf(b).alpha > 0.5)) {
    const pulse = 0.5 + 0.5 * Math.sin(now / 140);
    ctx.fillStyle = `rgba(210,75,45,${0.10 + 0.12 * pulse})`;
    ctx.fillRect(BX, BY, BW, CELL);
    ctx.fillStyle = `rgba(230,85,60,${0.5 + 0.5 * pulse})`;
    ctx.fillRect(BX, BY - 6, BW, 4);
  }

  const drag = present.drag;
  if (drag) {
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    for (let c = drag.min; c < drag.max + drag.b.len; c++)
      ctx.fillRect(BX + c * CELL + 1, BY + drag.b.row * CELL + 1, CELL - 2, CELL - 2);
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 2;
    const target = clamp(Math.round(viewOf(drag.b).vx), drag.min, drag.max);
    for (let c = target; c < target + drag.b.len; c++) {
      const x = BX + c * CELL + 2, y = BY + drag.b.row * CELL + 2;
      ctx.fillRect(x, y, CELL - 4, CELL - 4);
      ctx.strokeRect(x, y, CELL - 4, CELL - 4);
    }
  }

  ctx.save();
  ctx.beginPath(); ctx.rect(BX - 10, BY - 40, BW + 20, BH + 40); ctx.clip();
  for (const b of state.blocks) if (!drag || b !== drag.b) drawBlock(b, viewOf(b), false);
  if (drag) {
    drawBlock(drag.b, viewOf(drag.b), true);
    const x = BX + drag.col0 * CELL;
    const y = BY + drag.b.row * CELL;
    ctx.strokeStyle = C.white;
    ctx.lineWidth = 4;
    ctx.strokeRect(x + 2, y + 2, drag.b.len * CELL - 4, CELL - 4);
  }
  ctx.restore();

  ctx.globalAlpha = 1;
  eachParticle(p => {
    ctx.fillStyle = p.color;
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
    ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
    ctx.restore();
  });

  ctx.fillStyle = C.panel;
  ctx.fillRect(PANEL.x, PANEL.y, PANEL.w, PANEL.h);
  text('NEXT ROW', W / 2, PANEL.y + 42, 26, C.muted, 'center', 800);
  ctx.fillStyle = C.slot;
  for (let c = 0; c < COLS; c++) ctx.fillRect(BX + c * CELL + 1, PREV_Y + 1, CELL - 2, CELL - 2);
  for (const s of state.nextRow) {
    ctx.fillStyle = COLORS[s.color];
    rr(BX + s.col * CELL + PAD, PREV_Y + PAD, s.len * CELL - 2 * PAD, CELL - 2 * PAD, 7);
    ctx.fill();
  }
  text('BEST', PANEL.x + 42, PANEL.y + 222, 26, C.muted, 'left', 800);
  text(String(Math.max(state.best, state.score)), PANEL.x + 120, PANEL.y + 222, 30, '#a493b0', 'left', 800);
  text('LEVEL', PANEL.x + PANEL.w - 80, PANEL.y + 222, 26, C.muted, 'right', 800);
  text(String(state.level), PANEL.x + PANEL.w - 42, PANEL.y + 222, 30, '#a493b0', 'right', 800);
  const prog = (state.lines % 10) / 10;
  ctx.fillStyle = C.slot; rr(PANEL.x + 42, PANEL.y + 182, PANEL.w - 84, 8, 4); ctx.fill();
  if (prog > 0) { ctx.fillStyle = '#6c5c78'; rr(PANEL.x + 42, PANEL.y + 182, (PANEL.w - 84) * prog, 8, 4); ctx.fill(); }

  ctx.restore();

  ctx.save();
  ctx.translate(0, OY);
  if (state.phase === 'pause') {
    ctx.fillStyle = 'rgba(16,11,19,0.82)';
    ctx.fillRect(0, -OY, W, VH);
    drawCard(95, 500, 560, 300);
    text('PAUSED', W / 2, 590, 64, C.white);
    drawButton(PA_RESUME, 'RESUME', COLORS[1]);
  }
  if (state.phase === 'over') {
    ctx.save();
    ctx.globalAlpha = present.overlayA;
    ctx.fillStyle = 'rgba(16,11,19,0.84)';
    ctx.fillRect(0, -OY, W, VH);
    const dy = (1 - present.overlayA) * 40;
    ctx.translate(0, dy);
    drawCard(95, 380, 560, 610);
    text('GAME OVER', W / 2, 465, 62, C.white);
    text('SCORE', W / 2, 555, 28, C.muted);
    text(String(state.score), W / 2, 625, 96, C.white);
    if (state.newBest) {
      const pulse = 1 + 0.05 * Math.sin(performance.now() / 160);
      ctx.save(); ctx.translate(W / 2, 715); ctx.scale(pulse, pulse);
      text('NEW HIGH SCORE!', 0, 0, 34, COLORS[4]);
      ctx.restore();
    } else {
      text('HIGH SCORE', W / 2, 715, 28, C.muted);
    }
    text(String(state.best), W / 2, 775, 58, COLORS[4]);
    drawButton(GO_RESTART, 'RESTART', COLORS[0]);
    ctx.restore();
  }
  ctx.restore();
}
