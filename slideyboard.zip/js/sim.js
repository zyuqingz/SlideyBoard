// Pure board rules. No canvas, DOM, or timers.

export const W = 750, H = 1334;
export const COLS = 9, ROWS = 10, CELL = 70, PAD = 3;
export const BX = (W - COLS * CELL) / 2;
export const BW = COLS * CELL, BH = ROWS * CELL;
export const START_ROWS = 4;

export const COLORS = ['#f0912b', '#97b545', '#d24b2d', '#2f9b98', '#ffd570'];

export function createState(best = 0) {
  return {
    blocks: [],
    nextRow: [],
    score: 0,
    best,
    bestAtStart: best,
    level: 1,
    lines: 0,
    phase: 'play',
    nextId: 1,
    hasMoved: false,
    newBest: false
  };
}

export function createTurnScore() {
  return { combo: 0, pts: 0, awarded: 0 };
}

function rand(random, n) {
  return Math.floor(random() * n);
}

function weighted(random, weights) {
  let tot = 0;
  for (const w of weights) tot += w;
  let r = random() * tot;
  for (let i = 0; i < weights.length; i++) {
    if (r < weights[i]) return i;
    r -= weights[i];
  }
  return weights.length - 1;
}

function makeBlock(state, spec, row) {
  return { id: state.nextId++, row, col: spec.col, len: spec.len, color: spec.color };
}

// Always at least one gap. Larger pieces get likelier as level rises.
export function genRow(level, random = Math.random) {
  const L = level - 1;
  const gapIdx = weighted(random, [3 + 3 * L, 22, 34, Math.max(10, 28 - 2 * L), Math.max(3, 13 - 2 * L)]);
  const gapCount = gapIdx + 1;
  const gaps = new Set();
  while (gaps.size < gapCount) gaps.add(rand(random, COLS));
  const lenW = [Math.max(6, 30 - 3 * L), 32, Math.min(34, 22 + 2 * L), Math.min(40, 14 + 3 * L)];
  const row = [];
  let c = 0, prevColor = -1, prevEnd = -1;
  while (c < COLS) {
    if (gaps.has(c)) { c++; continue; }
    let run = 0;
    while (c + run < COLS && !gaps.has(c + run)) run++;
    while (run > 0) {
      const len = weighted(random, lenW.slice(0, Math.min(4, run))) + 1;
      let color;
      do { color = rand(random, COLORS.length); } while (color === prevColor && prevEnd === c);
      row.push({ col: c, len, color });
      prevColor = color;
      prevEnd = c + len;
      c += len;
      run -= len;
    }
  }
  return row;
}

export function buildGrid(state) {
  const g = [];
  for (let r = 0; r < ROWS; r++) g.push(new Array(COLS).fill(null));
  for (const b of state.blocks) {
    if (b.row < 0 || b.row >= ROWS) continue;
    for (let i = 0; i < b.len; i++) g[b.row][b.col + i] = b;
  }
  return g;
}

function spanFree(g, r, c, len) {
  for (let i = 0; i < len; i++) if (g[r][c + i]) return false;
  return true;
}

// Drop every unsupported block as far as it can go (bottom-up single pass).
// Commits row immediately. Visual vy catches up in the presenter.
export function computeGravity(state) {
  const g = buildGrid(state);
  const moved = [];
  const sorted = state.blocks.slice().sort((a, b) => b.row - a.row);
  for (const b of sorted) {
    let r = b.row;
    while (r + 1 < ROWS && spanFree(g, r + 1, b.col, b.len)) r++;
    if (r !== b.row) {
      for (let i = 0; i < b.len; i++) { g[b.row][b.col + i] = null; g[r][b.col + i] = b; }
      moved.push({ id: b.id, from: b.row, to: r });
      b.row = r;
    }
  }
  return moved;
}

export function fullRows(state) {
  const g = buildGrid(state);
  const out = [];
  for (let r = 0; r < ROWS; r++) if (g[r].every(Boolean)) out.push(r);
  return out;
}

export function slideRange(state, block) {
  const g = buildGrid(state);
  let min = block.col, max = block.col;
  while (min - 1 >= 0 && !g[block.row][min - 1]) min--;
  while (max + block.len < COLS && !g[block.row][max + block.len]) max++;
  return [min, max];
}

export function touchingTop(state) {
  return state.blocks.some(b => b.row === 0);
}

export function awardRows(state, rows, st) {
  for (let i = 0; i < rows.length; i++) {
    st.combo++;
    st.pts += COLS * 10 * state.level * st.combo;
  }
  const gained = st.pts - st.awarded;
  st.awarded = st.pts;
  state.score += gained;
  state.lines += rows.length;
  state.level = 1 + Math.floor(state.lines / 10);
  const bestUpdated = state.score > state.best;
  if (bestUpdated) state.best = state.score;
  return { gained, pts: st.pts, mult: st.combo, bestUpdated };
}

export function removeByIds(state, ids) {
  state.blocks = state.blocks.filter(b => !ids.has(b.id));
}

// Shift the board up one row and append the preview as the new bottom row.
export function rise(state, random = Math.random) {
  for (const b of state.blocks) b.row -= 1;
  const fresh = [];
  for (const spec of state.nextRow) fresh.push(makeBlock(state, spec, ROWS - 1));
  state.blocks.push(...fresh);
  state.nextRow = genRow(state.level, random);
  return fresh;
}

export function resetGame(state, random = Math.random) {
  state.blocks = [];
  state.nextId = 1;
  state.score = 0;
  state.level = 1;
  state.lines = 0;
  state.phase = 'play';
  state.hasMoved = false;
  state.newBest = false;
  state.bestAtStart = state.best;
  for (let i = 0; i < START_ROWS; i++) {
    for (const b of state.blocks) b.row--;
    for (const spec of genRow(state.level, random)) state.blocks.push(makeBlock(state, spec, ROWS - 1));
    for (;;) {
      computeGravity(state);
      const full = fullRows(state);
      if (!full.length) break;
      state.blocks = state.blocks.filter(b => !full.includes(b.row));
    }
  }
  state.nextRow = genRow(state.level, random);
}
