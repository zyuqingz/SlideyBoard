// Wires input, turn animation, and the frame loop around the pure board.

import {
  W, H, COLS, ROWS, CELL, BX, COLORS,
  createState, createTurnScore, computeGravity, fullRows, slideRange,
  touchingTop, awardRows, removeByIds, rise, resetGame
} from './sim.js';
import {
  Ease, tween, wait, updateTweens, clearTweens,
  spawnParticle, updateParticles, clearParticles
} from './fx.js';
import {
  layout, bindCanvas, toLogical, toOverlay, hit,
  GO_RESTART, PA_RESUME, draw
} from './render.js';

const canvas = document.getElementById('game');
bindCanvas(canvas);

const BEST_KEY = 'slidey_best';
function loadBest() {
  try { return parseInt(localStorage.getItem(BEST_KEY) || '0', 10) || 0; } catch (e) { return 0; }
}
function saveBest(v) {
  try { localStorage.setItem(BEST_KEY, String(v)); } catch (e) {}
}

const state = createState(loadBest());
const views = new Map();
const present = { displayScore: 0, shake: 0, overlayA: 0, comboFx: null, drag: null };
let busy = false;

function blankView(block) {
  return { vx: block.col, vy: block.row, flash: 0, alpha: 1, s: 1, sq: 0, danger: 0,
    clearing: false };
}

function viewOf(block) {
  let v = views.get(block.id);
  if (!v) { v = blankView(block); views.set(block.id, v); }
  return v;
}

function syncViews() {
  const keep = new Set();
  for (const b of state.blocks) {
    keep.add(b.id);
    if (!views.has(b.id)) views.set(b.id, blankView(b));
  }
  for (const id of views.keys()) if (!keep.has(id)) views.delete(id);
}

function startGame() {
  clearTweens();
  clearParticles();
  views.clear();
  resetGame(state);
  syncViews();
  present.displayScore = 0;
  present.shake = 0;
  present.overlayA = 0;
  present.comboFx = null;
  present.drag = null;
  busy = false;
}

function landSquash(block, d) {
  const amp = Math.min(0.22, 0.1 + 0.04 * d);
  const v = viewOf(block);
  tween(320, t => { v.sq = amp * t; }, Ease.damped);
}

async function applyGravity() {
  const moved = computeGravity(state);
  if (!moved.length) return false;
  await Promise.all(moved.map(m => {
    const block = state.blocks.find(b => b.id === m.id);
    const v = viewOf(block);
    const d = m.to - m.from;
    const dur = 110 + 95 * Math.sqrt(d);
    return tween(dur, t => { v.vy = m.from + d * t; }, Ease.in)
      .then(() => { v.vy = m.to; landSquash(block, d); });
  }));
  return true;
}

async function clearRows(rows, st) {
  const victims = state.blocks.filter(b => rows.includes(b.row));
  const rowOrder = rows.slice().sort((a, b) => b - a);
  const clears = victims.map(b => ({
    b, v: viewOf(b), burst: false,
    delay: Math.abs(b.col + b.len / 2 - COLS / 2) / (COLS / 2) * 70
      + Math.min(3, rowOrder.indexOf(b.row)) * 24
  }));
  for (const { v } of clears) v.clearing = true;
  const duration = 320 + Math.max(...clears.map(c => c.delay));
  await tween(duration, t => {
    for (const clear of clears) {
      const { b, v, delay } = clear;
      const p = clamp((t * duration - delay) / 320, 0, 1);
      // Pop up uniformly, then shrink away in a center-out ripple.
      if (p < 0.5) {
        const q = Ease.outBack(p / 0.5);
        v.s = 1 + 0.12 * q;
        v.flash = q;
      } else {
        const q = (p - 0.5) / 0.5;
        v.s = 1.12 * (1 - Ease.inCubic(q));
        v.flash = 1 - Ease.out(q);
        if (!clear.burst) {
          clear.burst = true;
          burstBlock(b);
        }
      }
    }
  }, Ease.lin);
  removeByIds(state, new Set(victims.map(b => b.id)));
  syncViews();
  const award = awardRows(state, rows, st);
  if (award.bestUpdated) saveBest(state.best);
  present.comboFx = { pts: award.pts, mult: award.mult, t0: performance.now() };
}

function burstBlock(b) {
  for (let i = 0; i < b.len; i++) {
    const cx = BX + (b.col + i + 0.5) * CELL, cy = layout.BY + (b.row + 0.5) * CELL;
    for (let k = 0; k < 3; k++) {
      spawnParticle({
        x: cx + (Math.random() - 0.5) * 32, y: cy + (Math.random() - 0.5) * 24,
        vx: (cx - W / 2) * 0.65 + (Math.random() - 0.5) * 440,
        vy: -240 - Math.random() * 400,
        size: 8 + Math.random() * 12, color: COLORS[b.color],
        life: 0.55 + Math.random() * 0.35, rot: Math.random() * 6
      });
    }
  }
}

async function settle(st) {
  for (;;) {
    await applyGravity();
    const full = fullRows(state);
    if (!full.length) break;
    await clearRows(full, st);
  }
}

async function riseRow() {
  rise(state);
  syncViews();
  const moving = state.blocks.slice();
  await tween(210, p => {
    for (const b of moving) viewOf(b).vy = b.row + 1 - p;
  }, Ease.out);
  for (const b of moving) viewOf(b).vy = b.row;
}

async function resolveTurn() {
  busy = true;
  const st = createTurnScore();
  await settle(st);
  if (touchingTop(state)) { await gameOver(); return; }
  await riseRow();
  await settle(st);
  busy = false;
}

async function gameOver() {
  busy = true;
  const top = state.blocks.filter(b => b.row === 0);
  tween(450, p => { present.shake = (1 - p) * 14 * Math.sin(p * 45); }, Ease.lin);
  await tween(350, p => top.forEach(b => { viewOf(b).danger = p; }), Ease.out);
  const moving = state.blocks.slice();
  await tween(260, p => { for (const b of moving) viewOf(b).vy = b.row - p * 0.35; }, Ease.out);
  await wait(250);
  state.newBest = state.score > state.bestAtStart && state.score > 0;
  if (state.score > state.best) state.best = state.score;
  saveBest(state.best);
  state.phase = 'over';
  busy = false;
  tween(300, p => { present.overlayA = p; }, Ease.out);
}

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

canvas.addEventListener('pointerdown', e => {
  e.preventDefault();
  const p = toLogical(e);
  const op = toOverlay(p);
  if (state.phase === 'over') {
    if (present.overlayA > 0.5 && hit(GO_RESTART, op)) startGame();
    return;
  }
  if (state.phase === 'pause') {
    if (hit(PA_RESUME, op)) state.phase = 'play';
    return;
  }
  if (hit(layout.RESTART_BTN, p)) { startGame(); return; }
  if (hit(layout.PAUSE_BTN, p)) { state.phase = 'pause'; present.drag = null; return; }
  if (busy || present.drag) return;
  const c = Math.floor((p.x - BX) / CELL), r = Math.floor((p.y - layout.BY) / CELL);
  if (c < 0 || c >= COLS || r < 0 || r >= ROWS) return;
  const row = state.blocks.filter(b => b.row === r);
  let b = null;
  for (const block of row) if (c >= block.col && c < block.col + block.len) b = block;
  if (!b) return;
  const [min, max] = slideRange(state, b);
  present.drag = { b, id: e.pointerId, x0: p.x, col0: b.col, min, max };
  try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
});

canvas.addEventListener('pointermove', e => {
  const drag = present.drag;
  if (!drag || e.pointerId !== drag.id) return;
  e.preventDefault();
  const p = toLogical(e);
  viewOf(drag.b).vx = clamp(drag.col0 + (p.x - drag.x0) / CELL, drag.min, drag.max);
});

function endDrag(e) {
  const drag = present.drag;
  if (!drag || e.pointerId !== drag.id) return;
  const { b, col0 } = drag;
  present.drag = null;
  const v = viewOf(b);
  const target = clamp(Math.round(v.vx), 0, COLS - b.len);
  const from = v.vx;
  b.col = target;
  busy = true;
  tween(90, p => { v.vx = from + (target - from) * p; }, Ease.out).then(() => {
    v.vx = target;
    if (target !== col0) { state.hasMoved = true; resolveTurn(); }
    else busy = false;
  });
}
canvas.addEventListener('pointerup', endDrag);
canvas.addEventListener('pointercancel', endDrag);
canvas.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
document.addEventListener('gesturestart', e => e.preventDefault());
window.addEventListener('keydown', e => {
  if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
    if (state.phase !== 'over') {
      state.phase = state.phase === 'pause' ? 'play' : 'pause';
      present.drag = null;
    }
  }
  if ((e.key === 'r' || e.key === 'R') && (state.phase === 'over' || state.phase === 'pause')) startGame();
});

let last = performance.now();
function frame(t) {
  const dt = Math.min(0.05, (t - last) / 1000);
  last = t;
  updateTweens(t);
  updateParticles(dt);
  const d = state.score - present.displayScore;
  present.displayScore = Math.abs(d) < 1 ? state.score : present.displayScore + d * Math.min(1, dt * 9);
  draw(t, state, viewOf, present);
  requestAnimationFrame(frame);
}

startGame();
requestAnimationFrame(frame);

window.__slidey = {
  get state() {
    return {
      blocks: state.blocks.map(b => {
        const v = viewOf(b);
        return { id: b.id, row: b.row, col: b.col, len: b.len, vy: v.vy, s: v.s, sq: v.sq };
      }),
      score: state.score,
      level: state.level,
      lines: state.lines,
      busy,
      over: state.phase === 'over',
      paused: state.phase === 'pause',
      best: state.best
    };
  },
  get layout() {
    return {
      W, H, VH: layout.VH, OY: layout.OY, BX, BY: layout.BY, HY: layout.HY,
      CELL, COLS, ROWS, panelY: layout.PANEL.y
    };
  }
};
